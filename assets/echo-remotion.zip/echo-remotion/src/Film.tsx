import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Audio,Img,Sequence,staticFile,useCurrentFrame,interpolate,Easing,delayRender,continueRender,cancelRender} from 'remotion';
import {scenes,Scene} from './story';
import {DynamicArt} from './FullMotion';

const GOLD='#dbc595', IVORY='#f5ecd9', INK='#3e3c32';
const clamp=(v:number)=>Math.max(0,Math.min(1,v));
const ease=(v:number)=>v*v*(3-2*v);
const ramp=(t:number,a:number,b:number)=>ease(clamp((t-a)/(b-a)));
const fade=(t:number,a:number,b:number,d=.42)=>ramp(t,a,a+d)*(1-ramp(t,b-d,b));
const rnd=(n:number)=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)};
const InkLine:React.FC<{d:string;progress:number;color?:string;opacity?:number;width?:number}>=({d,progress,color=GOLD,opacity=.7,width=1.4})=><path d={d} fill="none" stroke={color} strokeWidth={width} pathLength={1} strokeDasharray="1" strokeDashoffset={1-clamp(progress)} opacity={opacity}/>;
const Svg:React.FC<{children:React.ReactNode;style?:React.CSSProperties}>=({children,style})=><svg viewBox="0 0 1920 940" style={{position:'absolute',inset:0,width:'100%',height:'100%',...style}}>{children}</svg>;
const Text:React.FC<{x:number;y:number;size?:number;children:React.ReactNode;style?:React.CSSProperties}>=({x,y,size=42,children,style})=><div style={{position:'absolute',left:x,top:y,fontSize:size,color:IVORY,fontFamily:'serif',letterSpacing:2,...style}}>{children}</div>;
const Seal:React.FC<{x:number;y:number;size?:number;opacity?:number;rotation?:number}>=({x,y,size=90,opacity=.8,rotation=0})=><div style={{position:'absolute',left:x,top:y,width:size,height:size,opacity,transform:`rotate(${rotation}deg)`,border:'2px solid #dbc595',borderRadius:'50%',display:'grid',placeItems:'center',color:'#dbc595',fontSize:size*.45}}>✦</div>;

const Motes:React.FC<{t:number;snow?:boolean}>=({t,snow=false})=><Svg>{Array.from({length:snow?65:35},(_,i)=>{
 const x=(rnd(i+80)*2000+Math.sin(t*.11+i)*18)%2000;
 const y=((rnd(i+400)*1100+(snow?t*19:-t*3.6)*(0.4+rnd(i+30)))%1100+1100)%1100-80;
 return <circle key={i} cx={x} cy={y} r={snow?.7+rnd(i+18)*1.7:.6+rnd(i+18)*1.15} fill={snow?'#dfe9f1':GOLD} opacity={(snow?.16:.10)+rnd(i+270)*.17}/>;
})}</Svg>;

const Opening:React.FC<{t:number;title:boolean}>=({t,title})=>{
 const show=ramp(t,.5,2.1),a=title?ramp(t,.4,2):ramp(t,1,6);
 return <>
  <Svg style={{opacity:show}}>
   <InkLine d="M 198 336 C 437 240 637 370 814 312 S 1160 205 1444 327" progress={a} opacity={title?.28:.43}/>
   {Array.from({length:14},(_,i)=><g key={i} opacity={ramp(t,.7+i*.16,1.2+i*.16)*.6}><circle cx={230+i*88} cy={315+Math.sin(i*.8)*43} r={i%3===0?2.1:1.1} fill={GOLD}/>{i%3===0&&<path d={`M ${230+i*88-5} ${315+Math.sin(i*.8)*43} h 10 M ${230+i*88} ${310+Math.sin(i*.8)*43} v 10`} stroke={GOLD} strokeWidth=".5"/>}</g>)}
  </Svg>
  {!title&&<Text x={135} y={292} size={71} style={{opacity:ramp(t,1.1,2.7)*.65,letterSpacing:15}}>何 以 回 答</Text>}
  {title&&<div style={{position:'absolute',left:200,top:230,width:760,textAlign:'center',opacity:show,transform:`translateY(${(1-show)*18}px)`}}>
   <div style={{fontFamily:'serif',fontSize:146,letterSpacing:34,textIndent:34,lineHeight:1.3,color:IVORY}}>回声</div>
   <div style={{height:1,width:290,background:`linear-gradient(90deg,transparent,${GOLD},transparent)`,margin:'26px auto 26px'}}/>
   <div style={{fontFamily:'Georgia, serif',fontSize:51,letterSpacing:6,color:IVORY}}>ChatGPT 简史</div>
   <div style={{fontFamily:'Georgia, serif',fontSize:23,color:GOLD,letterSpacing:2,marginTop:23}}>From the first word to the next question</div>
   <div style={{fontFamily:'Georgia, serif',fontSize:22,color:'#ded3bc',letterSpacing:5,marginTop:38}}>2017 — 2026</div>
  </div>}
  {title&&<Seal x={1070} y={240} size={112} opacity={ramp(t,1,3)*.75}/>}
  <div style={{position:'absolute',right:160,top:330,width:350,height:420,background:`radial-gradient(ellipse,rgba(246,173,74,${.034+Math.sin(t*1.7)*.006}),transparent 68%)`,mixBlendMode:'screen'}}/>
 </>;
};

const Attention:React.FC<{t:number}>=({t})=>{
 const words=[['语言',290,342],['世界',610,282],['提问',945,370],['理解',1390,295],['你',1210,490]] as const;
 return <>
 <Svg style={{opacity:fade(t,.5,11.2,.65)}}>
  {words.map(([word,x,y],i)=><g key={word} opacity={ramp(t,.8+i*.18,1.8+i*.18)}>
   {words.slice(i+1).map(([_,xx,yy],j)=><InkLine key={j} d={`M ${x+26} ${y+35} Q ${(x+xx)/2} ${Math.min(y,yy)-110-j*17} ${xx+26} ${yy+35}`} progress={ramp(t,1.6+i*.25,4.6+i*.25)} opacity={.16+j*.025}/>) }
   <circle cx={x+26} cy={y+35} r={3} fill={GOLD}/>
  </g>)}
 </Svg>
 {words.map(([w,x,y],i)=><Text key={w} x={x} y={y-18} size={34} style={{opacity:ramp(t,.8+i*.18,1.8+i*.18)*.85,textShadow:'0 2px 18px #080e18'}}>{w}</Text>)}
 <Text x={360} y={570} size={38} style={{fontFamily:'Georgia, serif',letterSpacing:1,opacity:ramp(t,4,5.4)*.85}}>Attention is all you need.</Text>
 </>;
};

const Pages:React.FC<{t:number;long:boolean}>=({t,long})=>{
 const rows=long?['语言不止记录已经发生的世界。','它也把尚未发生的故事，','交给下一个词。']:['让语言成为一条河流。','让每一个词，走向下一个词。'];
 return <div style={{position:'absolute',left:long?1070:245,top:long?300:410,width:620,opacity:fade(t,.6,9.3,.6),transform:`translateY(${(1-ramp(t,.6,2))*15}px)`}}>
  <div style={{fontSize:20,letterSpacing:5,color:GOLD,fontFamily:'Georgia, serif',marginBottom:23}}>A LANGUAGE IN THE MAKING</div>
  {rows.map((s,i)=><div key={s} style={{fontFamily:'serif',fontSize:long?37:38,color:IVORY,lineHeight:2,letterSpacing:3,opacity:ramp(t,1+i*1.2,1.7+i*1.2),textShadow:'0 2px 14px #000'}}>{s.slice(0,Math.floor(clamp((t-1-i*1.2)/1.8)*s.length))}<span style={{color:GOLD,opacity:t<3.8+i*1.2?1:0}}>│</span></div>)}
  <div style={{width:440,height:1,background:GOLD,opacity:.45,transformOrigin:'left',transform:`scaleX(${ramp(t,3,5.5)})`,marginTop:20}}/>
  {!long&&<div style={{fontSize:23,letterSpacing:2,color:GOLD,fontFamily:'Georgia, serif',marginTop:18,opacity:ramp(t,4.5,6)}}>pre-train → fine-tune</div>}
  {long&&<div style={{fontSize:23,color:GOLD,fontFamily:'Georgia, serif',marginTop:18,opacity:ramp(t,5,7)}}>Capability brings responsibility.</div>}
 </div>;
};

const Scale:React.FC<{t:number}>=({t})=>{
 const n=Math.round(175000000000*ramp(t,.7,5.4));
 return <>
  <div style={{position:'absolute',left:850,top:220,width:890,textAlign:'center',color:INK,opacity:ramp(t,.6,1.6)}}>
   <div style={{fontFamily:'Georgia, serif',fontSize:85,letterSpacing:3,fontVariantNumeric:'tabular-nums'}}>{n.toLocaleString('en-US')}</div>
   <div style={{fontFamily:'Georgia, serif',fontSize:25,letterSpacing:4,marginTop:14}}>parameters · GPT-3</div>
  </div>
  <Svg style={{mixBlendMode:'multiply',opacity:.45}}>{Array.from({length:24},(_,i)=>{
   const x=320+i*56,y=408+Math.sin(i*.22+t*.17)*30;
   return <g key={i} opacity={ramp(t,.8+i*.1,2+i*.1)}><circle cx={x} cy={y} r={1.2} fill={INK}/>{i<23&&<path d={`M ${x} ${y} Q ${x+28} ${y-18} ${x+56} ${408+Math.sin((i+1)*.22+t*.17)*30}`} stroke={INK} strokeWidth=".7" fill="none"/>}</g>;
  })}</Svg>
 </>;
};

const Alignment:React.FC<{t:number}>=({t})=>{
 const c='#575244';return <>
 <Text x={390} y={242} size={73} style={{color:c,fontFamily:'Georgia, serif',letterSpacing:1,opacity:ramp(t,.5,1.7)}}>The measure is human.</Text>
 <Text x={395} y={355} size={24} style={{color:c,letterSpacing:5,opacity:ramp(t,.8,2)}}>人类反馈 · HUMAN FEEDBACK</Text>
 {['清楚地理解问题','诚实地表达边界','给出更有帮助的回答'].map((v,i)=><Text key={v} x={520} y={435+i*83} size={37} style={{color:c,opacity:ramp(t,1.6+i*.7,2.4+i*.7)}}>{v}<span style={{fontFamily:'Georgia, serif',fontSize:23,color:'#9b8c69',marginLeft:90}}>{['understand','be honest','be helpful'][i]}</span></Text>)}
 <Svg><InkLine color="#a18b59" d="M 440 458 l 13 12 29 -38 M 440 541 l 13 12 29 -38 M 440 624 l 13 12 29 -38" progress={ramp(t,3,6)} width={1.8}/><InkLine color="#ac9665" d="M 503 664 Q 832 643 1250 657" progress={ramp(t,4.8,7.2)} opacity={.7}/></Svg>
 <div style={{position:'absolute',left:1420,top:455,width:132,height:132,border:'1px solid #a5937055',borderRadius:'50%',opacity:ramp(t,4,6),transform:`rotate(${-12+(1-ramp(t,4,6))*12}deg)`,display:'flex',alignItems:'center',justifyContent:'center',color:'#967b4e',fontFamily:'serif',fontSize:41}}>意图</div>
 </>;
};

const Conversation:React.FC<{t:number}>=({t})=>{
 const q='为什么天空是蓝色的？',a='因为大气对短波蓝光的散射更强。';
 const p=ramp(t,2.8,4.8),qChars=Math.floor(clamp((t-3.1)/1.4)*q.length),aChars=Math.floor(clamp((t-5.3)/2.2)*a.length);
 return <>
 <div style={{position:'absolute',left:220,top:302,color:IVORY,opacity:ramp(t,1,3)}}>
  <div style={{fontFamily:'Georgia, serif',fontSize:100,letterSpacing:0}}>ChatGPT</div>
  <div style={{fontFamily:'serif',fontSize:34,letterSpacing:10,marginTop:22,color:GOLD}}>一个窗口，万千问题</div>
  <div style={{width:250,height:1,background:GOLD,opacity:.45,marginTop:30,transformOrigin:'left',transform:`scaleX(${ramp(t,2,4)})`}}/>
 </div>
 <div style={{position:'absolute',left:1045,top:350,width:674,boxSizing:'border-box',padding:'38px 43px 34px',background:'linear-gradient(115deg,#f0e7d4f3,#e6d8bff0)',boxShadow:'0 16px 55px #070b1590',color:INK,transform:`perspective(1800px) rotateY(-6deg) rotateZ(-2deg) translateY(${(1-p)*35}px)`,opacity:p}}>
  <div style={{fontFamily:'Georgia, serif',fontSize:23,letterSpacing:2,paddingBottom:21,borderBottom:'1px solid #786f5350'}}>A conversation begins</div>
  <div style={{fontFamily:'serif',fontSize:33,lineHeight:1.8,marginTop:23}}>{q.slice(0,qChars)}</div>
  <div style={{fontFamily:'serif',fontSize:29,lineHeight:1.7,marginTop:13,color:'#646453',minHeight:60}}>{a.slice(0,aChars)}<span style={{opacity:t<8?1:0,color:'#9a815a'}}>▏</span></div>
  <div style={{fontFamily:'serif',fontSize:18,color:'#8f836c',letterSpacing:3,marginTop:17}}>对话示意</div>
 </div>
 <Svg>{[0,1,2,3,4,5,6,7].map(i=><circle key={i} cx={860+i*95} cy={247+Math.sin(i)*29} r={1.6} fill={GOLD} opacity={ramp(t,8+i*.2,10+i*.2)*.6}/>)}</Svg>
 </>;
};

const Vision:React.FC<{t:number}>=({t})=><>
 <Svg style={{opacity:fade(t,2,14.9,1)}}>
  <InkLine d="M 620 229 C 955 75 1312 159 1450 376 C 1495 448 1463 585 1373 634" progress={ramp(t,2.4,8)} opacity={.48}/>
  <InkLine d="M 552 464 C 596 612 792 700 947 658" progress={ramp(t,3,7.5)} opacity={.30}/>
  <circle cx={1303} cy={488} r={30+Math.sin(t*.5)*1.5} fill="none" stroke={GOLD} strokeWidth=".8" opacity={ramp(t,4,6)*.45}/>
  <circle cx={1303} cy={488} r="3" fill={GOLD} opacity={ramp(t,4,6)*.65}/>
 </Svg>
 <Text x={250} y={420} size={31} style={{opacity:ramp(t,2.7,4.2),color:GOLD,letterSpacing:6}}>文字</Text>
 <Text x={250} y={483} size={31} style={{opacity:ramp(t,4.4,5.9),color:GOLD,letterSpacing:6}}>图像</Text>
 <Text x={250} y={563} size={24} style={{opacity:ramp(t,6,7.7)*.8,fontFamily:'Georgia, serif',letterSpacing:2}}>Beyond the written word</Text>
 </>;

const Waveform:React.FC<{t:number;globalFrame:number}>=({t,globalFrame})=>{
 const a=.4+.15*Math.sin(globalFrame*.13);
 let d='';for(let i=0;i<=200;i++){const x=270+i*6.8,w=Math.pow(Math.sin(i*Math.PI/200),2);const y=510+w*(Math.sin(i*.27-t*4.1)*16+Math.sin(i*.66+t*3.6)*9+Math.sin(i*.081-t*2)*24)*(0.48+a);d+=`${i?'L':'M'} ${x} ${y} `;}
 return <>
 <Svg style={{opacity:fade(t,1.1,14.4,1)}}><path d={d} fill="none" stroke={GOLD} strokeWidth="1.8" opacity=".72"/><path d={d} fill="none" stroke="#eadcbe" strokeWidth="5" opacity=".10"/><line x1="270" x2="1630" y1="510" y2="510" stroke={GOLD} strokeWidth=".6" opacity=".18"/></Svg>
 <Text x={400} y={362} size={25} style={{fontFamily:'Georgia, serif',letterSpacing:3,opacity:ramp(t,2,4),color:GOLD}}>see</Text>
 <Text x={915} y={362} size={25} style={{fontFamily:'Georgia, serif',letterSpacing:3,opacity:ramp(t,3.1,5.1),color:GOLD}}>hear</Text>
 <Text x={1430} y={362} size={25} style={{fontFamily:'Georgia, serif',letterSpacing:3,opacity:ramp(t,4.2,6.2),color:GOLD}}>speak</Text>
 </>;
};

const Reasoning:React.FC<{t:number}>=({t})=><>
 <Svg style={{opacity:fade(t,1,15.3,1)}}>
  <InkLine d="M 970 761 C 1040 720 1110 660 1039 614 S 1111 546 1130 501 S 1070 480 1212 424 S 1270 379 1325 337 S 1430 276 1465 253" progress={ramp(t,1.6,11)} opacity={.56} width={1.6}/>
  {[ [1039,614],[1130,501],[1212,424],[1325,337],[1465,253] ].map(([x,y],i)=><g key={i} opacity={ramp(t,3+i*1.6,4.5+i*1.6)}><circle cx={x} cy={y} r="13" fill="none" stroke={GOLD} strokeWidth=".8" opacity=".5"/><circle cx={x} cy={y} r="2.2" fill={GOLD}/></g>)}
 </Svg>
 <Text x={1600} y={264} size={50} style={{writingMode:'vertical-rl',letterSpacing:20,color:'#eadbbd',opacity:ramp(t,2,4.4)}}>循序而行</Text>
 <Text x={250} y={500} size={27} style={{fontFamily:'Georgia, serif',opacity:ramp(t,5,7),color:GOLD,letterSpacing:2}}>A little more time to think.</Text>
 </>;

const Confluence:React.FC<{t:number}>=({t})=><>
 <Svg style={{opacity:fade(t,1,13.3,.8)}}>
  <InkLine d="M 450 335 C 685 335 720 479 1030 458 S 1370 430 1510 452" progress={ramp(t,1.6,5.9)} opacity={.68}/>
  <InkLine d="M 450 590 C 685 590 720 439 1030 458 S 1370 430 1510 452" progress={ramp(t,2.4,7.8)} opacity={.68}/>
  <circle cx="1030" cy="458" r={10+ramp(t,4,8)*7} fill="none" stroke={GOLD} strokeWidth=".8" opacity={ramp(t,4,6)*.7}/>
  <circle cx="1510" cy="452" r="3" fill={GOLD} opacity={ramp(t,6,8)}/>
 </Svg>
 <Text x={325} y={269} size={37} style={{opacity:ramp(t,1.2,2.4),color:IVORY}}>快答</Text>
 <Text x={325} y={615} size={37} style={{opacity:ramp(t,2.4,3.6),color:IVORY}}>深思</Text>
 <Text x={1200} y={345} size={66} style={{fontFamily:'Georgia, serif',letterSpacing:5,opacity:ramp(t,6,8)}}>GPT-5</Text>
 </>;

const Genealogy:React.FC<{t:number;dynamic?:boolean}>=({t,dynamic=false})=>{
 const nodes=[['GPT-1','2018',480,622],['GPT-2','2019',720,575],['GPT-3','2020',1050,570],['GPT-3.5','2022',1320,505],['GPT-4','2023',680,414],['GPT-4o','2024',1150,360],['o1','2024',1420,326],['GPT-5','2025',855,270],['GPT-6','2026',1070,194]] as const;
 return <>
 <Svg>
  <InkLine d="M 960 737 C 914 655 987 595 960 522 C 933 446 967 377 956 306 S 998 221 1000 146" progress={ramp(t,.5,5.9)} color="#675940" opacity={.7} width={2}/>
  {nodes.map(([name,yr,x,y],i)=><g key={name} opacity={ramp(t,1+i*.37,1.8+i*.37)}><InkLine d={`M ${i<4?960:i<7?954:985} ${y+35} Q ${(x+960)/2} ${y+63} ${x} ${y}`} progress={ramp(t,.7+i*.37,1.5+i*.37)} color="#675940" width={1}/><circle cx={x} cy={y} r="4" fill="#947b4a"/><circle cx={x} cy={y} r="10" fill="none" stroke="#947b4a" strokeWidth=".7" opacity=".5"/></g>)}
 </Svg>
 {nodes.map(([name,yr,x,y],i)=><div key={name} style={{position:'absolute',left:x-115,top:y-57,width:230,textAlign:'center',color:INK,opacity:ramp(t,1+i*.37,1.8+i*.37)}}><div style={{fontFamily:'Georgia, serif',fontSize:30,letterSpacing:1}}>{name}</div><div style={{fontFamily:'Georgia, serif',fontSize:19,color:'#8a7b60',marginTop:2}}>{yr}</div></div>)}
 <Text x={1700} y={280} size={47} style={{writingMode:'vertical-rl',letterSpacing:16,color:'#685d47',opacity:ramp(t,.5,2)}}>枝叶相承</Text>
 <Text x={195} y={dynamic?430:546} size={dynamic?24:26} style={{fontFamily:'Georgia, serif',letterSpacing:1,color:'#8a7b60',opacity:ramp(t,4.5,6)}}>One line of inquiry.<br/>Many forms of intelligence.</Text>
 </>;
};

const Astra:React.FC<{t:number}>=({t})=>{
 const cx=1170,cy=441,p=ramp(t,1,4.3);
 return <>
  <Svg style={{opacity:p}}>
   <ellipse cx={cx} cy={cy} rx="290" ry="181" fill="none" stroke={GOLD} strokeWidth=".65" opacity=".32" transform={`rotate(${-20+t*.3} ${cx} ${cy})`}/>
   <ellipse cx={cx} cy={cy} rx="210" ry="285" fill="none" stroke={GOLD} strokeWidth=".65" opacity=".28" transform={`rotate(${30+t*.55} ${cx} ${cy})`}/>
   <circle cx={cx} cy={cy} r="215" fill="none" stroke={GOLD} strokeWidth=".7" opacity=".32"/>
   {Array.from({length:12},(_,i)=><line key={i} x1={cx+Math.cos(i*Math.PI/6)*215} y1={cy+Math.sin(i*Math.PI/6)*215} x2={cx+Math.cos(i*Math.PI/6)*(i%3===0?228:221)} y2={cy+Math.sin(i*Math.PI/6)*(i%3===0?228:221)} stroke={GOLD} strokeWidth="1" opacity=".5"/>)}
   <circle cx={cx+Math.cos(t*.19)*290} cy={cy+Math.sin(t*.19)*181} r="3.5" fill={GOLD}/>
  </Svg>
  <Seal x={cx-65} y={cy-65} size={130} opacity={p*.84} rotation={t*.45}/>
  <Text x={243} y={327} size={76} style={{opacity:ramp(t,.8,2.4),fontFamily:'Georgia, serif',letterSpacing:7}}>Astra</Text>
  <Text x={247} y={431} size={34} style={{opacity:ramp(t,2.1,3.5),color:GOLD,letterSpacing:6}}>由知，至行</Text>
  <div style={{position:'absolute',left:247,top:530,color:IVORY,opacity:ramp(t,4,6),fontFamily:'serif',fontSize:25,letterSpacing:5}}>查证 <span style={{color:GOLD,margin:'0 17px'}}>→</span>计划 <span style={{color:GOLD,margin:'0 17px'}}>→</span>执行</div>
 </>;
};

const SolLuna:React.FC<{t:number}>=({t})=><>
 <Svg style={{opacity:ramp(t,.8,2.3)}}><circle cx="632" cy="395" r="67" fill="none" stroke={GOLD} strokeWidth="1" opacity=".65"/>{Array.from({length:16},(_,i)=>{const a=i*Math.PI/8+t*.02;return <line key={i} x1={632+Math.cos(a)*77} y1={395+Math.sin(a)*77} x2={632+Math.cos(a)*87} y2={395+Math.sin(a)*87} stroke={GOLD} strokeWidth=".8" opacity=".55"/>})}<path d="M 1315 335 A 65 65 0 1 0 1360 450 A 60 60 0 0 1 1315 335" fill="none" stroke={GOLD} strokeWidth="1" opacity=".65"/><line x1="890" x2="1030" y1="395" y2="395" stroke={GOLD} strokeWidth=".8" opacity=".35"/></Svg>
 <Text x={558} y={498} size={61} style={{fontFamily:'Georgia, serif',letterSpacing:7,opacity:ramp(t,1,2.4)}}>Sol</Text>
 <Text x={1248} y={498} size={61} style={{fontFamily:'Georgia, serif',letterSpacing:7,opacity:ramp(t,1.5,2.9)}}>Luna</Text>
 </>;

const Dawn:React.FC<{t:number;ending:boolean}>=({t,ending})=><>
 <div style={{position:'absolute',left:1170,top:110,width:580,height:600,background:'radial-gradient(ellipse,#e8c78815,transparent 64%)',mixBlendMode:'screen',opacity:.6+Math.sin(t*.65)*.12}}/>
 {!ending&&<div style={{position:'absolute',left:250,top:307,color:IVORY,opacity:ramp(t,.6,2),transform:`translateY(${(1-ramp(t,.6,2))*16}px)`}}>
 <div style={{fontFamily:'Georgia, serif',fontSize:98,letterSpacing:5}}>GPT-6.1 <span style={{fontFamily:'Georgia, serif',fontSize:79}}>Sol</span></div>
 <div style={{height:1,width:350,background:`linear-gradient(90deg,${GOLD},transparent)`,margin:'30px 0 24px',opacity:.6}}/>
 <div style={{fontFamily:'serif',fontSize:32,letterSpacing:11,color:GOLD}}>晨光，又近了一程</div>
 <div style={{fontFamily:'Georgia, serif',fontSize:24,letterSpacing:2,marginTop:25,opacity:.8}}>The next chapter of useful intelligence.</div>
 </div>}
 {ending&&<div style={{position:'absolute',left:245,top:360,opacity:ramp(t,.2,1.1),color:IVORY}}><div style={{fontFamily:'serif',fontSize:55,letterSpacing:8}}>故事还在继续。</div><div style={{fontFamily:'serif',fontSize:36,letterSpacing:4,marginTop:29,color:GOLD}}>下一页，始于你的问题。</div><div style={{fontFamily:'Georgia, serif',fontSize:24,letterSpacing:1,marginTop:29,opacity:.75}}>The next page begins with your question.</div></div>}
 </>;

const CaptionRail:React.FC<{scene:Scene;t:number}>=({scene,t})=>{
 const light=scene.art==='paper.jpg';
 return <>{scene.captions.map((c,i)=>{
 const op=fade(t,c.at,c.end,.4);if(op<.001)return null;
 return <div key={i} style={{position:'absolute',left:160,right:160,top:779,textAlign:'center',opacity:op,transform:`translateY(${(1-ramp(t,c.at,c.at+.5))*7}px)`,color:light?INK:IVORY,textShadow:light?'none':'0 2px 14px #070b0fe6,0 1px 3px #000'}}>
 <div style={{fontFamily:'serif',fontSize:39,lineHeight:1.55,letterSpacing:2.5,fontWeight:400}}>{c.cn}</div>
 <div style={{fontFamily:'Georgia, serif',fontSize:23,lineHeight:1.5,letterSpacing:.65,marginTop:8,color:light?'#756a55':'#e2d5bd'}}>{c.en}</div>
 </div>;
 })}</>;
};

const artworkLabels:Record<string,string>={
 'pitcher.jpg':'VERMEER · ca. 1662', 'wave-met.jpg':'HOKUSAI · ca. 1830–32',
 'pearl.jpg':'VERMEER · ca. 1665','boating.jpg':'MANET · 1874','cypresses.jpg':'VAN GOGH · 1889',
};
const Chapter:React.FC<{scene:Scene;index:number;dynamic?:boolean}>=({scene,index,dynamic=false})=>{
 const frame=useCurrentFrame(),t=frame/30,duration=scene.end-scene.start;
 const progress=clamp(t/duration),paper=scene.art==='paper.jpg',light=paper||scene.id==='gpt3';
 const op=index===0?ramp(t,0,1.3):ramp(t,0,1.2);
 const textOp=ramp(t,.7,1.6)*(1-ramp(t,duration-.35,duration+.3));
 const pan=(index%2===0?1:-1)*interpolate(progress,[0,1],[-18,18],{easing:Easing.inOut(Easing.quad)});
 const zoom=paper?1:1.035+progress*(scene.id==='gpt4'?.065:.045);
 const artBrightness=paper?1:scene.id==='gpt3'?.91:scene.id==='gpt4'?.8:scene.id==='gpt5'?.76:.86;
 const f={t,globalFrame:Math.round(scene.start*30)+frame};
 return <AbsoluteFill style={{opacity:op,overflow:'hidden',top:70,height:940,bottom:'auto'}}>
 {dynamic?<DynamicArt scene={scene} brightness={artBrightness}/>:<Img src={staticFile('art/'+scene.art)} style={{position:'absolute',width:'100%',height:'100%',objectFit:'cover',objectPosition:scene.focus??'50% 50%',transform:`translate(${pan}px,${(progress-.5)*-12}px) scale(${zoom})`,filter:`brightness(${artBrightness}) saturate(.88)`}}/>}
 {!paper&&<AbsoluteFill style={{background:'linear-gradient(180deg,#05080c4a 0%,transparent 37%,transparent 61%,#04070be0 100%)'}}/>}
 {!paper&&<AbsoluteFill style={{background:`radial-gradient(ellipse at ${scene.id==='gpt3'?'50% 40%':'57% 45%'},transparent 33%,#04060965 100%)`}}/>}
 {!dynamic&&!paper&&scene.id!=='gpt3'&&<Motes t={t} snow={scene.art==='city.jpg'}/>}
 <div style={{position:'absolute',inset:0,opacity:textOp}}>
  {scene.id==='opening'&&<Opening t={t} title={false}/>}
  {scene.id==='title'&&<Opening t={t} title/>}
  {scene.id==='attention'&&<Attention t={t}/>}
  {scene.id==='gpt1'&&<Pages t={t} long={false}/>}
  {scene.id==='gpt2'&&<Pages t={t} long/>}
  {scene.id==='gpt3'&&<Scale t={t}/>}
  {scene.id==='alignment'&&<Alignment t={t}/>}
  {scene.id==='chatgpt'&&<Conversation t={t}/>}
  {scene.id==='gpt4'&&<Vision t={t}/>}
  {scene.id==='omni'&&<Waveform {...f}/>}
  {scene.id==='reasoning'&&<Reasoning t={t}/>}
  {scene.id==='gpt5'&&<Confluence t={t}/>}
  {scene.id==='evolution'&&<Genealogy t={t} dynamic={dynamic}/>}
  {scene.id==='astra'&&<Astra t={t}/>}
  {scene.id==='sol-luna'&&<SolLuna t={t}/>}
  {scene.id==='sol61'&&<div style={{opacity:dynamic?1-ramp(t,4.8,5.8):1}}><Dawn t={t} ending={false}/></div>}
  {scene.id==='ending'&&!dynamic&&<Dawn t={t} ending/>}
 </div>
 <div style={{position:'absolute',left:127,top:62,color:light?INK:IVORY,opacity:dynamic&&scene.id==='ending'?0:textOp}}>
  <div style={{display:'flex',alignItems:'center',gap:18}}><span style={{height:1,width:31,background:light?'#8d8063':GOLD,opacity:.6}}/><span style={{fontFamily:'Georgia, serif',fontSize:26,letterSpacing:4}}>{scene.date}</span></div>
  <div style={{fontFamily:'Georgia, serif',fontSize:19,letterSpacing:3,margin:'13px 0 0 49px',color:light?'#786b51':GOLD}}>{scene.model}</div>
 </div>
 {scene.id!=='title'&&scene.id!=='opening'&&scene.id!=='ending'&&<div style={{position:'absolute',right:125,top:65,color:light?'#7b715d':GOLD,opacity:textOp*.7,fontFamily:'serif',fontSize:20,letterSpacing:5}}>{String(index-1).padStart(2,'0')} / {scene.chapter}</div>}
 <CaptionRail scene={scene} t={t}/>
 {dynamic&&scene.id==='ending'&&<div style={{position:'absolute',left:0,width:1920,top:625,textAlign:'center',fontFamily:'serif',fontSize:30,letterSpacing:8,color:GOLD,opacity:ramp(t,1.5,2.2)}}>下一页，始于你的问题。</div>}
 {artworkLabels[scene.art]&&<div style={{position:'absolute',left:126,bottom:27,fontFamily:'Georgia, serif',fontSize:14,letterSpacing:2,color:light?'#776c56':GOLD,opacity:textOp*.48}}>{artworkLabels[scene.art]}</div>}
 </AbsoluteFill>;
};

export const Film:React.FC<{dynamic?:boolean}>=({dynamic=false})=>{
 const frame=useCurrentFrame();
 const [handle]=useState(()=>delayRender('Loading archival typography'));
 useEffect(()=>{
  document.fonts.ready.then(()=>continueRender(handle)).catch(cancelRender);
 },[handle]);
 const grainX=-(Math.floor(frame/3)%4)*93,grainY=-(Math.floor(frame/7)%4)*81;
 return <AbsoluteFill style={{background:'#080b0d'}}>
  {scenes.map((scene,i)=><Sequence key={scene.id} from={Math.round(scene.start*30)} durationInFrames={Math.round((scene.end-scene.start)*30)+((i<scenes.length-1)?36:0)}><Chapter scene={scene} index={i} dynamic={dynamic}/></Sequence>)}
  <AbsoluteFill style={{top:70,height:940,bottom:'auto',backgroundImage:`url(${staticFile('art/grain.png')})`,backgroundPosition:`${grainX}px ${grainY}px`,backgroundSize:'512px 512px',mixBlendMode:'soft-light',opacity:.2,pointerEvents:'none'}}/>
  {!dynamic&&<AbsoluteFill style={{opacity:ramp(frame/30,176.75,178),background:'#080b0d'}}/>}
  {/* Add a licensed audio track here if the project calls for music. */}
 </AbsoluteFill>;
};
