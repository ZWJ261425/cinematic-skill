import React, {useEffect, useLayoutEffect, useRef, useState} from 'react';
import {AbsoluteFill, Audio, cancelRender, continueRender, delayRender, staticFile, useCurrentFrame} from 'remotion';

const W=1920,H=940, GOLD='#dfc693', IVORY='#f4ead5';
const clamp=(n:number)=>Math.max(0,Math.min(1,n));
const smooth=(n:number)=>{const p=clamp(n);return p*p*(3-2*p)};
const ramp=(t:number,a:number,b:number)=>smooth((t-a)/(b-a));
const seed=(n:number)=>{const a=Math.sin(n*127.1+311.7)*43758.5453;return a-Math.floor(a)};
export type Assets=Record<string,HTMLImageElement>;
type Point={x:number;y:number;ox:number;oy:number;delay:number;phase:number;r:number};
export type Cache={eyes:HTMLCanvasElement; globe:HTMLCanvasElement; water:HTMLCanvasElement; points:Point[]};
export type CameraView={zoom:number;cx:number;cy:number};
export const canvas=(w:number,h:number)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
const ellipseMask=(ctx:CanvasRenderingContext2D,x:number,y:number,rx:number,ry:number)=>{
 ctx.save();ctx.translate(x,y);ctx.scale(rx,ry);const g=ctx.createRadialGradient(0,0,.60,0,0,1);g.addColorStop(0,'white');g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(-1,-1,2,2);ctx.restore();
};
export function prepare(a:Assets):Cache{
 const eyes=canvas(1808,2138),ec=eyes.getContext('2d')!;
 ec.drawImage(a.blink,0,0,1808,2138);
 const mask=canvas(1808,2138),mc=mask.getContext('2d')!;
 ellipseMask(mc,638,805,83,59);ellipseMask(mc,843,847,104,65);
 ec.globalCompositeOperation='destination-in';ec.drawImage(mask,0,0);
 const globe=canvas(380,380),gc=globe.getContext('2d')!;
 gc.drawImage(a.wheel,504,425,380,380,0,0,380,380);
 const gm=canvas(380,380);ellipseMask(gm.getContext('2d')!,190,190,163,170);
 gc.globalCompositeOperation='destination-in';gc.drawImage(gm,0,0);
 const water=canvas(1672,941);
 // Sample glyph pixels deterministically for the particle ending.
 // Each particle owns a seeded origin, target and delay; Remotion owns the clock.
 const lettering=canvas(W,H),lc=lettering.getContext('2d')!;
 lc.font='204px Georgia, serif';lc.textAlign='center';lc.textBaseline='middle';lc.fillStyle='white';lc.fillText('ChatGPT',W/2,465);
 const pixels=lc.getImageData(0,0,W,H).data,points:Point[]=[];
 for(let y=330;y<610;y+=3)for(let x=400;x<1520;x+=3){if(pixels[(y*W+x)*4+3]>110){const i=points.length;points.push({x:x+(seed(i+91)-.5)*1.9,y:y+(seed(i+170)-.5)*1.9,ox:seed(i+31)*2080-80,oy:seed(i+732)*1000-30,delay:seed(i+1601)*.9,phase:seed(i+800)*6.28,r:.56+seed(i+502)*.83})}}
 return {eyes,globe,water,points};
}
export function camera(ctx:CanvasRenderingContext2D,img:HTMLImageElement,z:number,cx:number,cy:number){
 const s=Math.max(W/img.width,H/img.height)*z;
 const safeX=Math.max(W/(2*s)+3,Math.min(img.width-W/(2*s)-3,cx));
 const safeY=Math.max(H/(2*s)+3,Math.min(img.height-H/(2*s)-3,cy));
 ctx.translate(W/2,H/2);ctx.scale(s,s);ctx.translate(-safeX,-safeY);
}
export function motes(ctx:CanvasRenderingContext2D,t:number,n:number,w:number,h:number,light=false){
 for(let i=0;i<n;i++){
  const x=seed(i+73)*w+Math.sin(t*.13+i)*12;
  const y=((seed(i+823)*h-t*(light?3.7:2.0)*(1+seed(i+19)))%h+h)%h;
  const r=light?.7+seed(i+543)*3.6:.4+seed(i+543)*1.1;
  const alpha=(light?.03:.08)+seed(i+218)*.13*(.65+.35*Math.sin(t*.8+i));
  ctx.globalAlpha=alpha;ctx.fillStyle='#fae2a5';
  if(light){ctx.shadowBlur=r*3;ctx.shadowColor='#fae2a5'}
  ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
 }
 ctx.globalAlpha=1;ctx.shadowBlur=0;
}
function flame(ctx:CanvasRenderingContext2D,t:number){
 const x=1175,y=477,wind=Math.sin(t*3.4)*2.2+Math.sin(t*9.1)*.7;
 const h=39+Math.sin(t*7.3)*3+Math.sin(t*12.7)*1.6;
 const breathe=.91+Math.sin(t*3.6)*.055+Math.sin(t*8.4)*.035;
 ctx.save();ctx.globalCompositeOperation='screen';
 let g=ctx.createRadialGradient(x,y-15,0,x,y-15,150);g.addColorStop(0,`rgba(244,164,67,${.15*breathe})`);g.addColorStop(.3,`rgba(230,121,39,${.05*breathe})`);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-150,y-165,300,300);
 ctx.globalCompositeOperation='source-over';
 g=ctx.createLinearGradient(x,y-h,x,y);g.addColorStop(0,'#fbe4a5');g.addColorStop(.4,'#ffd574');g.addColorStop(1,'#d87c29');ctx.fillStyle=g;ctx.shadowBlur=6;ctx.shadowColor='#ffc96f';
 ctx.beginPath();ctx.moveTo(x,y);ctx.bezierCurveTo(x-11,y-11,x-6,y-h*.7,x+wind,y-h);ctx.bezierCurveTo(x+4+wind,y-h*.6,x+11,y-9,x,y);ctx.fill();
 ctx.shadowBlur=2;ctx.fillStyle='#fff1c8';ctx.beginPath();ctx.moveTo(x,y-1);ctx.bezierCurveTo(x-4,y-8,x-2,y-20,x+wind*.4,y-25);ctx.bezierCurveTo(x+5,y-14,x+5,y-5,x,y-1);ctx.fill();
 ctx.restore();
}
export function library(ctx:CanvasRenderingContext2D,t:number,a:Assets,c:Cache,view?:CameraView){
 ctx.save();const p=ramp(t,0,8.6);camera(ctx,a.library,view?.zoom??1.035+.14*p,view?.cx??837+120*p,view?.cy??470-7*p);ctx.drawImage(a.library,0,0);
 // Copper instrument is separate from its pedestal. Its vertical axis stays mounted.
 ctx.save();ctx.translate(978,438);ctx.scale(.99-.12*Math.sin(t*.13),1);ctx.filter='brightness(.69) saturate(.78)';
 ctx.drawImage(a.wheel,-127,-107,254,214);
 ctx.save();ctx.translate(2,7);ctx.rotate(t*.18);ctx.drawImage(c.globe,-35.3,-35.3,70.6,70.6);ctx.restore();
 // The fixed foreground equatorial ring occludes the rotating inner globe.
 ctx.drawImage(a.wheel,0,624,1368,91,-127,-107+624*214/1150,254,91*214/1150);
 ctx.filter='none';ctx.restore();
 flame(ctx,t);
 // Existing painted stars gain restrained twinkle; points follow the window's space.
 ctx.save();ctx.globalCompositeOperation='screen';
 for(let i=0;i<38;i++){const x=1278+seed(i+932)*330,y=32+seed(i+922)*200;ctx.globalAlpha=.08+.22*Math.pow((1+Math.sin(t*(.9+seed(i+991)) +i))/2,3);ctx.fillStyle='#e6e2be';ctx.beginPath();ctx.arc(x,y,.45+seed(i+121)*.8,0,6.28);ctx.fill()}
 ctx.restore();
 motes(ctx,t,45,1672,941,true);ctx.restore();
}
function blinkAmount(t:number){
 let v=0;for(const at of [3.06,5.85]){const d=t-at;v=Math.max(v,ramp(d,0,.13)*(1-ramp(d,.18,.39)))}return v;
}
export function portrait(ctx:CanvasRenderingContext2D,t:number,a:Assets,c:Cache,view?:CameraView){
 ctx.save();const p=ramp(t,0,7.7);
 // Begin with the whole face; move closer to the eyes as the blink happens.
 const s=view?Math.max(W/a.portrait.width,H/a.portrait.height)*view.zoom:1.12+.43*p;
 ctx.translate(W/2,H/2);ctx.scale(s,s);ctx.translate(-(view?.cx??780-20*p),-(view?.cy??930-80*p));
 ctx.drawImage(a.portrait,0,0);ctx.globalAlpha=blinkAmount(t);ctx.drawImage(c.eyes,0,0);ctx.globalAlpha=1;
 // A barely changing warm bounce light keeps the face within the same painted palette.
 ctx.globalCompositeOperation='screen';const g=ctx.createRadialGradient(580,800,40,580,800,480);g.addColorStop(0,`rgba(248,210,137,${.012+.006*Math.sin(t*1.05)})`);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(100,320,960,960);ctx.restore();
}
export function lake(ctx:CanvasRenderingContext2D,t:number,a:Assets,c:Cache,view?:CameraView){
 ctx.save();const p=ramp(t,0,7.1);camera(ctx,a.dawn,view?.zoom??1.16-.095*p,view?.cx??955-60*p,view?.cy??484+5*p);ctx.drawImage(a.dawn,0,0);
 const wc=c.water.getContext('2d')!;wc.clearRect(0,0,1672,941);
 for(let y=519;y<941;y+=2){const depth=(y-519)/422;const amp=.45+depth*depth*4.2;const dx=amp*(Math.sin(y*.105-t*1.15)+.28*Math.sin(y*.23+t*.63));const sy=y+depth*.46*Math.sin(y*.14-t*.55);wc.drawImage(a.dawn,0,sy,1672,3,dx,y,1672,3)}
 // Protect the traveler, boat and shoreline while the painted water itself flows.
 wc.globalCompositeOperation='destination-in';const mask=wc.createLinearGradient(650,0,800,0);mask.addColorStop(0,'transparent');mask.addColorStop(1,'white');wc.fillStyle=mask;wc.fillRect(0,518,1672,423);wc.globalCompositeOperation='source-over';ctx.drawImage(c.water,0,0);
 ctx.save();ctx.globalCompositeOperation='screen';
 for(let i=0;i<65;i++){const y=535+seed(i+233)*393,depth=(y-535)/400;const x=1425-depth*125+(seed(i+241)-.5)*(25+depth*110);const shimmer=.018+.055*Math.pow((1+Math.sin(t*1.4+i*1.73))*.5,3);ctx.globalAlpha=shimmer;ctx.fillStyle='#ffe6a6';ctx.beginPath();ctx.ellipse(x,y,1.2+depth*7,.45+depth*.65,0,0,6.28);ctx.fill()}
 ctx.globalAlpha=1;
 let g=ctx.createRadialGradient(1432,295,5,1432,295,260);g.addColorStop(0,`rgba(255,216,123,${.085+.025*Math.sin(t*.94)})`);g.addColorStop(.45,'rgba(251,184,90,.022)');g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(1172,35,520,520);
 // Drifting, soft motes inside the light shaft, including near-lens bokeh.
 ctx.save();ctx.beginPath();ctx.moveTo(1440,295);ctx.lineTo(1550,920);ctx.lineTo(920,920);ctx.closePath();ctx.clip();motes(ctx,t,65,1672,941,true);ctx.restore();
 for(let i=0;i<5;i++){const x=980+seed(i+181)*410+t*(i%2?1.3:-.7),y=500+seed(i+161)*200;const haze=ctx.createRadialGradient(x,y,0,x,y,110);haze.addColorStop(0,`rgba(255,233,183,${.010+.006*Math.sin(t*.6+i)})`);haze.addColorStop(1,'transparent');ctx.fillStyle=haze;ctx.fillRect(x-110,y-110,220,220)}
 ctx.restore();ctx.restore();
}
export function ending(ctx:CanvasRenderingContext2D,t:number,a:Assets,c:Cache){
 ctx.fillStyle='#07111c';ctx.fillRect(0,0,W,H);
 ctx.save();ctx.globalAlpha=.24*(1-ramp(t,.4,3.3));camera(ctx,a.observatory,1.15,840,370);ctx.drawImage(a.observatory,0,0);ctx.restore();
 const g=ctx.createRadialGradient(960,460,20,960,460,810);g.addColorStop(0,'rgba(123,103,62,.065)');g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 // Background stars continue to live while the foreground particles find their letters.
 for(let i=0;i<130;i++){const x=seed(i+218)*W,y=seed(i+183)*H;ctx.globalAlpha=(.08+seed(i+418)*.2)*(.4+.6*Math.pow((1+Math.sin(t*.9+i))*.5,2));ctx.fillStyle=i%3===0?'#dfbc78':'#b4c4d1';ctx.beginPath();ctx.arc(x,y,.4+seed(i+817)*.9,0,6.28);ctx.fill()}
 ctx.globalAlpha=1;
 for(let i=0;i<c.points.length;i++){
  const q=c.points[i],raw=clamp((t-.6-q.delay)/3.95),p=smooth(raw),flight=1-p;
  const bend=Math.sin(p*Math.PI)*flight;
  const x=q.ox+(q.x-q.ox)*p+Math.sin(q.phase)*bend*190;
  const y=q.oy+(q.y-q.oy)*p+Math.cos(q.phase)*bend*125;
  const twinkle=.74+.26*Math.sin(t*(1.1+seed(i+62))+q.phase);
  ctx.globalAlpha=(.34+.53*p)*twinkle*ramp(t,0,.8);
  ctx.fillStyle=i%5===0?'#f7e7c6':i%3===0?'#d4ab66':'#e5cf9e';
  ctx.beginPath();ctx.arc(x,y,q.r*(.8+.2*p),0,6.28);ctx.fill();
  if(i%113===0){ctx.globalAlpha*=.26;ctx.fillRect(x-4,y-.28,8,.56);ctx.fillRect(x-.28,y-4,.56,8)}
 }
 ctx.globalAlpha=.12*ramp(t,4.6,5.5);ctx.font='204px Georgia, serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=IVORY;ctx.fillText('ChatGPT',960,465);ctx.globalAlpha=1;
}
const scenes=[
 {at:0,end:9.05,kind:'library',date:'2018 · 06',title:'GPT-1',cn:'预测下一个词，是这一程的起点。',en:'The journey begins with the next word.'},
 {at:8.4,end:16.2,kind:'portrait',date:'2023 · 03 · 14',title:'GPT-4',cn:'文字之外，世界开始成为问题的一部分。',en:'Beyond words, the world becomes part of the question.'},
 {at:15.55,end:23,kind:'lake',date:'2026 · 09 · 29',title:'GPT-6.1 Sol',cn:'从一个答案，走向一段可以完成的工作。',en:'From an answer to work carried through.'},
 {at:22.35,end:30,kind:'ending',date:'',title:'',cn:'',en:''},
];
export const MotionPreview:React.FC=()=>{
 const frame=useCurrentFrame(),t=frame/30,ref=useRef<HTMLCanvasElement>(null);
 const [handle]=useState(()=>delayRender('Loading motion plates and fonts'));
 const [loaded,setLoaded]=useState<{a:Assets;c:Cache}|null>(null);
 useEffect(()=>{
  let alive=true;
  const paths={library:'motion-assets/library-clean.png',wheel:'motion-assets/armillary.png',portrait:'art/pearl.jpg',blink:'motion-assets/portrait-blink.png',dawn:'art/dawn.jpg',observatory:'art/observatory.jpg'};
  Promise.all([
   Promise.all(Object.entries(paths).map(async([k,p])=>{const im=new Image();im.src=staticFile(p);await im.decode();return [k,im] as const})),
   document.fonts.ready,
  ]).then(([pairs])=>{if(alive){const a=Object.fromEntries(pairs);setLoaded({a,c:prepare(a)})}}).catch(cancelRender);
  return()=>{alive=false};
 },[]);
 useLayoutEffect(()=>{
  if(!loaded||!ref.current)return;
  const ctx=ref.current.getContext('2d')!;ctx.clearRect(0,0,W,H);ctx.fillStyle='#070c13';ctx.fillRect(0,0,W,H);
  for(const s of scenes){if(t<s.at||t>=s.end)continue;ctx.save();ctx.globalAlpha=s.at===0?1:ramp(t,s.at,s.at+.65);const local=t-s.at;
   // A full offscreen scene avoids individual overlapping elements leaking through dissolves.
   const layer=canvas(W,H),l=layer.getContext('2d')!;
   if(s.kind==='library')library(l,local,loaded.a,loaded.c);
   else if(s.kind==='portrait')portrait(l,local,loaded.a,loaded.c);
   else if(s.kind==='lake')lake(l,local,loaded.a,loaded.c);
   else ending(l,local,loaded.a,loaded.c);
   ctx.drawImage(layer,0,0);ctx.restore();
  }
  continueRender(handle);
 },[frame,loaded,handle]);
 return <AbsoluteFill style={{background:'#05080d',color:IVORY}}>
  {/* Supply licensed music before adding an Audio component. */}
  <div style={{position:'absolute',top:70,left:0,width:W,height:H,overflow:'hidden'}}>
   <canvas ref={ref} width={W} height={H} style={{position:'absolute',inset:0,width:W,height:H}}/>
   <AbsoluteFill style={{pointerEvents:'none',background:'linear-gradient(180deg,rgba(3,8,15,.32),transparent 28%,transparent 65%,rgba(3,8,15,.78)),radial-gradient(ellipse at center,transparent 40%,rgba(3,8,15,.32))'}}/>
   {scenes.slice(0,3).map(s=>{const opacity=ramp(t,s.at+.65,s.at+1.3)*(1-ramp(t,s.end-1.1,s.end-.6));return <AbsoluteFill key={s.kind} style={{opacity}}>
    <div style={{position:'absolute',left:128,top:58,fontFamily:'Georgia, serif',fontSize:22,letterSpacing:5,color:GOLD}}>{s.date}</div>
    <div style={{position:'absolute',left:128,top:94,fontFamily:'Georgia, serif',fontSize:40,letterSpacing:2,color:IVORY}}>{s.title}</div>
    <div style={{position:'absolute',bottom:83,left:120,width:1680,textAlign:'center',fontFamily:'serif',fontSize:38,letterSpacing:4,textShadow:'0 2px 16px #000'}}>{s.cn}</div>
    <div style={{position:'absolute',bottom:43,left:120,width:1680,textAlign:'center',fontFamily:'Georgia, serif',fontSize:24,letterSpacing:.7,color:GOLD}}>{s.en}</div>
   </AbsoluteFill>})}
   <div style={{position:'absolute',left:0,width:W,top:625,textAlign:'center',fontFamily:'serif',fontSize:30,letterSpacing:8,color:GOLD,opacity:ramp(t,27.7,28.7)}}>下一页，始于你的问题。</div>
  </div>
 </AbsoluteFill>;
};
