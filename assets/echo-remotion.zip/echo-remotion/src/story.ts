export type Caption = {at:number;end:number;cn:string;en:string};
export type Scene = {id:string;start:number;end:number;art:string;date:string;model:string;chapter:string;focus?:string;captions:Caption[]};
export const scenes:Scene[]=[
 {id:'opening',start:0,end:9,art:'library.jpg',date:'序',model:'THE QUESTION',chapter:'提问',captions:[
  {at:1.2,end:4.6,cn:'人类把问题写进书页，把答案交给时间。',en:'We wrote our questions into books, and entrusted the answers to time.'},
  {at:5,end:8.6,cn:'直到有一天，书页的另一端，传来了回声。',en:'Until, one day, an answer came from the other side.'}]},
 {id:'title',start:9,end:16,art:'library.jpg',date:'2017—2026',model:'A HISTORY OF CHATGPT',chapter:'回声',captions:[]},
 {id:'attention',start:16,end:27,art:'observatory.jpg',date:'2017.06',model:'TRANSFORMER',chapter:'关联',captions:[
  {at:1.1,end:5.2,cn:'2017 年，Transformer 改变了语言的读法。',en:'In 2017, the Transformer introduced a different way to read language.'},
  {at:5.7,end:10.6,cn:'词语不再独自前行，它们在上下文中彼此关联。',en:'Words could be understood through their relationships with one another.'}]},
 {id:'gpt1',start:27,end:36,art:'library.jpg',date:'2018.06',model:'GPT-1',chapter:'学习',captions:[
  {at:0.9,end:4.1,cn:'2018 年，GPT 从大量文字中学习。',en:'In 2018, GPT began learning from a large collection of text.'},
  {at:4.5,end:8.6,cn:'先预训练，再微调。预测下一个词，成为起点。',en:'Pre-training, then fine-tuning. Predicting the next word was a beginning.'}]},
 {id:'gpt2',start:36,end:45,art:'pitcher.jpg',date:'2019.02',model:'GPT-2',chapter:'续写',focus:'52% 38%',captions:[
  {at:0.9,end:4.1,cn:'2019 年，GPT-2 能续写更长的故事。',en:'In 2019, GPT-2 could sustain longer passages of writing.'},
  {at:4.5,end:8.6,cn:'能力越像人，关于滥用的担忧，也越清晰。',en:'More convincing language brought sharper concerns about misuse.'}]},
 {id:'gpt3',start:45,end:57,art:'wave-met.jpg',date:'2020.05',model:'GPT-3',chapter:'规模',focus:'50% 42%',captions:[
  {at:1,end:5.3,cn:'2020 年，1750 亿参数，把规模推向新岸。',en:'In 2020, GPT-3 reached a scale of 175 billion parameters.'},
  {at:5.9,end:11.6,cn:'只给几个例子，模型便能尝试新的任务。',en:'A few examples could guide the model toward a new task.'}]},
 {id:'alignment',start:57,end:66,art:'paper.jpg',date:'2022.01',model:'INSTRUCTGPT',chapter:'意图',captions:[
  {at:0.9,end:4.1,cn:'2022 年，InstructGPT 用人类反馈改进回答。',en:'In 2022, InstructGPT used human feedback to improve its responses.'},
  {at:4.6,end:8.6,cn:'它开始学习，什么样的回答，更符合人的意图。',en:'The aim was to follow human intent more faithfully.'}]},
 {id:'chatgpt',start:66,end:84,art:'city.jpg',date:'2022.11.30',model:'CHATGPT',chapter:'相逢',captions:[
  {at:0.9,end:4.6,cn:'11 月 30 日，ChatGPT 上线。',en:'On November 30, ChatGPT opened to the public.'},
  {at:5.1,end:10.6,cn:'模型走出论文，走进一个人人可以提问的窗口。',en:'The model left the research paper and entered an everyday conversation.'},
  {at:11.3,end:17.6,cn:'历史的转折，是技术终于有了普通人的入口。',en:'The turning point was a doorway that ordinary people could use.'}]},
 {id:'gpt4',start:84,end:99,art:'pearl.jpg',date:'2023.03.14',model:'GPT-4',chapter:'看见',focus:'50% 35%',captions:[
  {at:1,end:6.2,cn:'2023 年，GPT-4 把图像带进理解。',en:'In 2023, GPT-4 brought images into the conversation.'},
  {at:6.9,end:14.6,cn:'文字之外，世界开始成为问题的一部分。',en:'Beyond words, the visible world could become part of a question.'}]},
 {id:'omni',start:99,end:113,art:'boating.jpg',date:'2024.05.13',model:'GPT-4o',chapter:'往来',focus:'48% 42%',captions:[
  {at:0.9,end:6.1,cn:'2024 年，GPT-4o 让听、看、说更加连贯。',en:'In 2024, GPT-4o brought seeing, hearing and speaking closer together.'},
  {at:6.8,end:13.6,cn:'交互从一次次输入，走向更自然的往来。',en:'Interaction moved toward a more natural exchange.'}]},
 {id:'reasoning',start:113,end:128,art:'mountains.jpg',date:'2024.09.12',model:'o1',chapter:'求索',captions:[
  {at:0.9,end:6.1,cn:'同年秋天，o1 让推理有了更多时间。',en:'That autumn, o1 learned to spend more time reasoning before responding.'},
  {at:6.8,end:14.6,cn:'有些答案，需要走过几步，才看得清。',en:'Some answers become clearer only after taking a few more steps.'}]},
 {id:'gpt5',start:128,end:141,art:'cypresses.jpg',date:'2025.08.07',model:'GPT-5',chapter:'合流',focus:'50% 48%',captions:[
  {at:1,end:6.1,cn:'2025 年，GPT-5 把快答与深思纳入同一体系。',en:'In 2025, GPT-5 brought quick responses and deeper reasoning into one system.'},
  {at:6.7,end:12.6,cn:'简单的问题，轻快回应。复杂的问题，深入推理。',en:'Respond quickly when possible. Reason more deeply when needed.'}]},
 {id:'evolution',start:141,end:149,art:'paper.jpg',date:'2025—2026',model:'CONTINUING EVOLUTION',chapter:'迭代',captions:[
  {at:1,end:7.6,cn:'模型持续迭代，能力开始落在具体的工作里。',en:'Successive releases brought these abilities into practical work.'}]},
 {id:'astra',start:149,end:160,art:'observatory.jpg',date:'2026.09.03',model:'GPT-6 ASTRA',chapter:'行动',captions:[
  {at:1,end:5.1,cn:'2026 年 9 月，GPT-6 Astra 到来。',en:'In September 2026, GPT-6 Astra arrived.'},
  {at:5.6,end:10.6,cn:'回答之外，在工具与软件中推进多步任务。',en:'Beyond answering, working through multi-step tasks with tools.'}]},
 {id:'sol-luna',start:160,end:166,art:'city.jpg',date:'2026.09.22',model:'GPT-6 SOL / LUNA',chapter:'日常',captions:[
  {at:0.9,end:5.6,cn:'Sol 与 Luna，把不同的能力与成本，带进日常选择。',en:'Sol and Luna offered different balances of capability and cost.'}]},
 {id:'sol61',start:166,end:174,art:'dawn.jpg',date:'2026.09.29',model:'GPT-6.1 SOL',chapter:'晨光',captions:[
  {at:1,end:3.8,cn:'9 月 29 日，GPT-6.1 Sol 接过这一程。',en:'On September 29, GPT-6.1 Sol took the next step.'},
  {at:4.2,end:7.6,cn:'以更低成本，在多项工作评测中接近 Astra。',en:'Near-Astra scores on several work evaluations, at a lower cost.'}]},
 {id:'ending',start:174,end:178,art:'dawn.jpg',date:'未完',model:'THE NEXT QUESTION',chapter:'下一页',captions:[]}
];
