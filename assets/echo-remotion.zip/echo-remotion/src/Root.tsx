import React from 'react';
import {Composition} from 'remotion';
import {Film} from './Film';
import {MotionPreview} from './MotionPreview';
import {MotionFilm} from './FullMotion';
export const Root: React.FC = () => <><Composition id="Echo" component={Film} durationInFrames={5340} fps={30} width={1920} height={1080}/><Composition id="MotionPreview" component={MotionPreview} durationInFrames={900} fps={30} width={1920} height={1080}/><Composition id="EchoMotion" component={MotionFilm} durationInFrames={5340} fps={30} width={1920} height={1080}/></>;
