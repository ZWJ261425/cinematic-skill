import React,{createContext,useContext,useEffect,useLayoutEffect,useRef,useState} from 'react';
import {cancelRender,continueRender,delayRender,staticFile,useCurrentFrame} from 'remotion';
import {Assets,Cache,CameraView,canvas,camera,prepare,library,portrait,lake,ending,motes} from './MotionPreview';
import {Scene} from './story';
import {Film} from './Film';

const W=1920,H=940;
const clamp=(v:number)=>Math.max(0,Math.min(1,v));
const ease=(v:number)=>{const p=clamp(v);return p*p*(3-2*p)};
const ramp=(t:number,a:number,b:number)=>ease((t-a)/(b-a));
const seed=(n:number)=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)};
type Rect=[number,number,number,number];
type Patch={x:number;y:number;w:number;h:number;source:HTMLCanvasElement;mask:HTMLCanvasElement;scratch:HTMLCanvasElement};
type FullCache={base:Cache;patches:Record<string,Patch>;windows:{x:number;y:number;r:number;phase:number}[];traveler:Rect;walk0:HTMLCanvasElement;walk1:HTMLCanvasElement;walkMix:HTMLCanvasElement;obsGlobe:HTMLCanvasElement};
type State={a:Assets;c:FullCache};
const Context=createContext<State|null>(null);

function oval(ctx:CanvasRenderingContext2D,x:number,y:number,rx:number,ry:number,feather=.7){
 ctx.save();ctx.translate(x,y);ctx.scale(rx,ry);const g=ctx.createRadialGradient(0,0,feather,0,0,1);g.addColorStop(0,'white');g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(-1,-1,2,2);ctx.restore();
}
function makePatch(img:HTMLImageElement,rect:Rect,paint:(ctx:CanvasRenderingContext2D)=>void,cloud=false):Patch{
 const [x,y,w,h]=rect,source=canvas(w,h),sc=source.getContext('2d')!;sc.drawImage(img,x,y,w,h,0,0,w,h);
 const mask=canvas(w,h),mc=mask.getContext('2d')!;mc.save();mc.filter='blur(5px)';mc.translate(-x,-y);paint(mc);mc.restore();
 if(cloud){const p=sc.getImageData(0,0,w,h).data,m=mc.getImageData(0,0,w,h);for(let i=0;i<p.length;i+=4){const r=p[i],g=p[i+1],b=p[i+2],lum=(r+g+b)/3,chroma=Math.max(r,g,b)-Math.min(r,g,b);m.data[i+3]*=clamp((lum-100)/65)*clamp((52-chroma)/40)}mc.putImageData(m,0,0)}
 return {x,y,w,h,source,mask,scratch:canvas(w,h)};
}
function polygon(ctx:CanvasRenderingContext2D,points:number[][]){ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fillStyle='white';ctx.fill()}
function alphaBox(img:HTMLImageElement):Rect{
 const c=canvas(img.width,img.height),ctx=c.getContext('2d')!;ctx.drawImage(img,0,0);const p=ctx.getImageData(0,0,img.width,img.height).data;
 let left=img.width,right=0,top=img.height,bottom=0;
 const rows=new Uint32Array(img.height),cols=new Uint32Array(img.width);
 for(let y=0;y<img.height;y++)for(let x=0;x<img.width;x++)if(p[(y*img.width+x)*4+3]>96){rows[y]++;cols[x]++}
 for(let x=0;x<img.width;x++)if(cols[x]>8){left=Math.min(left,x);right=Math.max(right,x)}
 for(let y=0;y<img.height;y++)if(rows[y]>8){top=Math.min(top,y);bottom=Math.max(bottom,y)}
 return [left,top,right-left+1,bottom-top+1];
}
function fullPrepare(a:Assets):FullCache{
 const patches:Record<string,Patch>={};
 const add=(key:string,img:HTMLImageElement,rect:Rect,center:Rect,cloud=false)=>{patches[key]=makePatch(img,rect,ctx=>oval(ctx,...center),cloud)};
 patches.cityWater=makePatch(a.city,[280,525,1392,416],ctx=>{
  polygon(ctx,[[350,555],[810,576],[970,609],[1672,654],[1672,941],[765,941],[615,830],[403,775],[381,699],[337,650]]);
  ctx.globalCompositeOperation='destination-out';ctx.fillRect(1030,535,320,110);
 });
 patches.boatWater=makePatch(a.boating,[80,70,2180,730],ctx=>{oval(ctx,1150,385,1070,310,.85);ctx.globalCompositeOperation='destination-out';ctx.beginPath();ctx.ellipse(1410,480,420,430,0,0,6.28);ctx.fill()});
 add('boatWaterRight',a.boating,[2150,650,520,490],[2400,865,250,220]);
 add('dress',a.boating,[490,1320,1510,760],[1220,1750,710,300]);
 add('shirt',a.boating,[900,680,720,560],[1260,995,260,235]);
 add('sail',a.boating,[2480,100,280,720],[2650,370,104,243]);
 add('pitcherCloth',a.pitcher,[1090,1100,780,600],[1530,1425,310,220]);
 patches.wave=makePatch(a.wave,[500,210,1200,1510],ctx=>{
  oval(ctx,1100,890,590,680,.84);ctx.globalCompositeOperation='destination-out';
  polygon(ctx,[[100,940],[430,1090],[730,1200],[805,1390],[620,1530],[150,1290]]);
 });
 patches.cypressSky=makePatch(a.cypresses,[80,80,2630,1340],ctx=>{oval(ctx,1420,610,1360,615,.8);ctx.globalCompositeOperation='destination-out';polygon(ctx,[[2240,120],[2400,120],[2530,900],[2700,1280],[2150,1510],[2040,1240],[2130,900]])});
 patches.cypressTree=makePatch(a.cypresses,[1900,90,800,1450],ctx=>{polygon(ctx,[[2260,90],[2375,90],[2440,320],[2500,740],[2640,1180],[2530,1450],[2020,1500],[2040,1170],[2160,830],[2220,430]])});
 add('field',a.cypresses,[500,1500,1990,650],[1500,1830,950,235]);
 add('cloud1',a.mountainsClean,[260,130,660,380],[580,330,310,175],true);
 add('cloud2',a.mountainsClean,[680,280,640,550],[1040,620,280,225],true);
 add('cloud3',a.mountainsClean,[1000,440,672,501],[1390,710,275,210],true);
 add('observerCoat',a.observatoryClean,[980,625,85,150],[1022,703,34,64]);
 add('curtain',a.observatoryClean,[480,260,115,495],[542,560,48,180]);
 const cityCanvas=canvas(a.city.width,a.city.height),cc=cityCanvas.getContext('2d')!;cc.drawImage(a.city,0,0);const pixels=cc.getImageData(0,0,a.city.width,a.city.height).data;
 const windows:FullCache['windows']=[];
 for(let i=0;i<15000&&windows.length<90;i++){const x=Math.floor(600+seed(i+71)*1030),y=Math.floor(210+seed(i+163)*345),k=(y*a.city.width+x)*4;
  if(pixels[k]>150&&pixels[k+1]>75&&pixels[k+1]<205&&pixels[k+2]<pixels[k+1]*.70&&pixels[k]>pixels[k+1]*1.16)windows.push({x,y,r:.5+seed(i+792)*1.4,phase:seed(i+1300)*6.28});
 }
 const obsGlobe=canvas(188,188),oc=obsGlobe.getContext('2d')!;oc.drawImage(a.observatoryWheel,1510,380,188,188,0,0,188,188);
 const gm=canvas(188,188);oval(gm.getContext('2d')!,94,94,86,89);oc.globalCompositeOperation='destination-in';oc.drawImage(gm,0,0);
 const walk0=canvas(a.traveler.width,a.traveler.height),w0=walk0.getContext('2d')!;w0.drawImage(a.traveler,0,0);
 const walk1=canvas(a.traveler.width,a.traveler.height),w1=walk1.getContext('2d')!;w1.drawImage(a.traveler,0,0);
 const mask=canvas(a.traveler.width,a.traveler.height),mc=mask.getContext('2d')!,blend=mc.createLinearGradient(0,930,0,1030);blend.addColorStop(0,'transparent');blend.addColorStop(1,'white');mc.fillStyle=blend;mc.fillRect(0,0,mask.width,mask.height);
 const lower=canvas(mask.width,mask.height),lc=lower.getContext('2d')!;lc.drawImage(a.travelerStep,0,0,mask.width,mask.height);lc.globalCompositeOperation='destination-in';lc.drawImage(mask,0,0);
 w1.globalCompositeOperation='destination-out';w1.drawImage(mask,0,0);w1.globalCompositeOperation='source-over';w1.drawImage(lower,0,0);
 return {base:prepare(a),patches,windows,traveler:alphaBox(a.traveler),walk0,walk1,walkMix:canvas(walk0.width,walk0.height),obsGlobe};
}
function warp(ctx:CanvasRenderingContext2D,p:Patch,t:number,amount:number,mode:'water'|'cloth'|'cloud'|'tree',phase=0){
 const sc=p.scratch.getContext('2d')!;sc.clearRect(0,0,p.w,p.h);
 const step=mode==='tree'?3:4;
 for(let y=0;y<p.h;y+=step){const q=y/p.h;let dx=0,dy=0;
  if(mode==='water'){dx=amount*(.2+.8*q*q)*(Math.sin(y*.075-t*1.16+phase)+.27*Math.sin(y*.151+t*.51));dy=q*.4*Math.sin(y*.16-t*.6)}
  else if(mode==='cloth'){dx=amount*Math.sin(y*.013-t*.82+phase)*Math.sin(q*Math.PI);dy=amount*.22*Math.sin(t*.9+phase)}
  else if(mode==='tree'){dx=amount*Math.pow(1-q,1.45)*Math.sin(t*.68+q*.85+phase);dy=.4*Math.sin(t*.7)}
  else {dx=amount*(Math.sin(y*.018+t*.22+phase)+.4*Math.sin(y*.035-t*.17));dy=.5*Math.sin(y*.045+t*.21)}
  sc.drawImage(p.source,0,y,p.w,Math.min(step+1,p.h-y),dx,y+dy,p.w,Math.min(step+1,p.h-y));
 }
 sc.globalCompositeOperation='destination-in';sc.drawImage(p.mask,0,0);sc.globalCompositeOperation='source-over';ctx.drawImage(p.scratch,p.x,p.y);
}
function glow(ctx:CanvasRenderingContext2D,x:number,y:number,r:number,alpha:number,color='255,191,100'){
 ctx.save();ctx.globalCompositeOperation='screen';const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${color},${alpha})`);g.addColorStop(.3,`rgba(${color},${alpha*.27})`);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);ctx.restore();
}
function stars(ctx:CanvasRenderingContext2D,t:number){
 ctx.save();ctx.beginPath();ctx.moveTo(708,410);ctx.lineTo(712,145);ctx.quadraticCurveTo(955,-90,1480,0);ctx.lineTo(1490,510);ctx.lineTo(770,505);ctx.closePath();ctx.clip();ctx.globalCompositeOperation='screen';
 for(let i=0;i<115;i++){const x=727+seed(i+813)*800,y=20+seed(i+761)*420;const b=.12+.44*Math.pow((1+Math.sin(t*(.65+seed(i+823)*.6)+i))*.5,4);ctx.globalAlpha=b;ctx.fillStyle=i%4===0?'#efdeb9':'#ccdeec';ctx.beginPath();ctx.arc(x,y,.35+seed(i+620)*1.0,0,6.28);ctx.fill();if(i%19===0){ctx.globalAlpha=b*.22;ctx.fillRect(x-3,y-.3,6,.6);ctx.fillRect(x-.3,y-3,.6,6)}}
 ctx.restore();
}
function snowfall(ctx:CanvasRenderingContext2D,t:number){
 ctx.save();for(let i=0;i<135;i++){const depth=.2+seed(i+61)*.8,speed=8+depth*22;const y=((seed(i+401)*1080+t*speed)%1080)-70;
  const x=((seed(i+13)*1790+t*(1.6+depth*2.0)+Math.sin(t*.24+i)*14)%1790)-50;const r=.32+depth*1.8;
  ctx.globalAlpha=.08+depth*.20;ctx.fillStyle='#d9e4ed';ctx.beginPath();ctx.arc(x,y,r,0,6.28);ctx.fill();if(depth>.94){ctx.globalAlpha=.035;ctx.fillRect(x-.3,y-5,.6,5)}
 }ctx.restore();
}
function sceneView(scene:Scene,t:number):CameraView{
 const p=ramp(t,0,scene.end-scene.start);
 const lerp=(a:number,b:number)=>a+(b-a)*p;
 const choices:Record<string,[number,number,number,number,number,number]>={
  opening:[1.025,1.09,830,858,475,468],title:[1.09,1.145,858,925,468,466],
  attention:[1.105,1.025,875,837,466,456],gpt1:[1.035,1.105,837,915,480,465],
  gpt2:[1.035,1.12,1490,1435,1338,1290],gpt3:[1.045,1.09,1440,1370,914,915],
  alignment:[1.012,1.022,957,966,540,537],chatgpt:[1.055,1.115,860,808,470,466],
  gpt4:[1.04,1.35,880,812,910,854],omni:[1.10,1.035,1450,1370,866,860],
  reasoning:[1.025,1.105,820,883,475,455],gpt5:[1.115,1.045,1440,1360,1100,1094],
  evolution:[1.012,1.025,964,958,540,536],astra:[1.035,1.13,842,907,471,456],
  'sol-luna':[1.12,1.065,910,858,472,470],sol61:[1.15,1.065,937,875,484,489],
 };
 const v=choices[scene.id]??[1.05,1.08,837,850,470,470];return {zoom:lerp(v[0],v[1]),cx:lerp(v[2],v[3]),cy:lerp(v[4],v[5])};
}
function drawArt(ctx:CanvasRenderingContext2D,scene:Scene,t:number,state:State){
 const {a,c}=state,view=sceneView(scene,t),global=scene.start+t;
 if(scene.id==='ending'){ending(ctx,(global-171.5)*1.18,a,c.base);return}
 if(scene.art==='library.jpg'){library(ctx,global,a,c.base,view);return}
 if(scene.art==='pearl.jpg'){portrait(ctx,t,a,c.base,view);return}
 if(scene.art==='dawn.jpg'){
  lake(ctx,t,a,c.base,view);
  if(global>=171.5){const layer=canvas(W,H);ending(layer.getContext('2d')!,(global-171.5)*1.18,a,c.base);ctx.save();ctx.globalAlpha=ramp(global,171.5,174.5);ctx.drawImage(layer,0,0);ctx.restore()}return;
 }
 const key=scene.art==='observatory.jpg'?'observatoryClean':scene.art==='mountains.jpg'?'mountainsClean':scene.art==='wave-met.jpg'?'wave':scene.art.slice(0,-4);
 const im=a[key];ctx.save();camera(ctx,im,view.zoom,view.cx,view.cy);ctx.drawImage(im,0,0);
 if(scene.art==='city.jpg'){
  warp(ctx,c.patches.cityWater,global,4.7,'water');
  glow(ctx,139,288,105,.08+.025*Math.sin(global*1.43)+.011*Math.sin(global*3.13));
  for(const q of c.windows)glow(ctx,q.x,q.y,3.4+q.r,.045+.045*Math.pow((1+Math.sin(global*.9+q.phase))*.5,2));
  snowfall(ctx,global);motes(ctx,global,12,1672,941,false);
 }else if(scene.art==='observatory.jpg'){
  stars(ctx,global);
  ctx.save();ctx.translate(1620,650);ctx.scale(.96+.032*Math.cos(global*.12),1);ctx.translate(-1620,-650);ctx.drawImage(a.observatoryWheel,536,0,1155,650);
  ctx.save();ctx.translate(536+1604*.69,474*.69);ctx.rotate(global*.052);ctx.drawImage(c.obsGlobe,-65,-65,130,130);ctx.restore();
  ctx.drawImage(a.observatoryWheel,970,484,702,90,536+970*.69,484*.69,702*.69,90*.69);ctx.restore();
  warp(ctx,c.patches.observerCoat,global,.72,'cloth',1.9);warp(ctx,c.patches.curtain,global,2.3,'cloth',.6);
  glow(ctx,172,675,55,.06+.025*Math.sin(global*3.3));motes(ctx,global,22,1672,941,true);
 }else if(scene.art==='mountains.jpg'){
  warp(ctx,c.patches.cloud1,t,4,'cloud',.7);warp(ctx,c.patches.cloud2,t,5,'cloud',1.2);warp(ctx,c.patches.cloud3,t,4.5,'cloud',2.6);
  // Author the traveler along the existing stone path; shrink with distance.
  const p=ramp(t,0,15),footX=225+p*111,footY=748-p*34,scale=1-p*.17,step=t*3.4;
  ctx.save();ctx.fillStyle='rgba(12,10,7,.19)';ctx.beginPath();ctx.ellipse(footX-5,footY-1,19*scale,3.2*scale,0,0,6.28);ctx.fill();ctx.translate(footX,footY-Math.abs(Math.sin(step))*1.5);ctx.rotate(Math.sin(step)*.006);ctx.filter='brightness(.85) saturate(.84)';
  const [sx,sy,sw,sh]=c.traveler,ww=67*scale,hh=123*scale;
  const phase=(t/.86)%1,weight=ramp(phase,.14,.36)*(1-ramp(phase,.64,.86));
  const mix=c.walkMix.getContext('2d')!;mix.clearRect(0,0,c.walkMix.width,c.walkMix.height);mix.globalAlpha=1-weight;mix.drawImage(c.walk0,0,0);mix.globalCompositeOperation='lighter';mix.globalAlpha=weight;mix.drawImage(c.walk1,0,0);mix.globalAlpha=1;mix.globalCompositeOperation='source-over';
  ctx.drawImage(c.walkMix,sx,sy,sw,sh,-ww/2,-hh,ww,hh);ctx.filter='none';ctx.restore();
  glow(ctx,1440,123,310,.024+.009*Math.sin(t*.55));motes(ctx,t,14,1672,941,false);
 }else if(scene.art==='pitcher.jpg'){
  warp(ctx,c.patches.pitcherCloth,t,2.2,'cloth',1.1);
  ctx.save();ctx.globalCompositeOperation='screen';const g=ctx.createLinearGradient(100,200,1700,1800);g.addColorStop(0,`rgba(255,230,164,${.045+.012*Math.sin(t*.58)})`);g.addColorStop(.55,'rgba(255,236,190,.007)');g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(140,400);ctx.lineTo(420,180);ctx.lineTo(1810,2140);ctx.lineTo(350,2150);ctx.closePath();ctx.fill();motes(ctx,t,55,2800,3149,true);ctx.restore();
 }else if(scene.art==='boating.jpg'){
  warp(ctx,c.patches.boatWater,t,6.0,'water',.9);warp(ctx,c.patches.boatWaterRight,t,4.0,'water',2);
  warp(ctx,c.patches.dress,t,2.7,'cloth',.5);warp(ctx,c.patches.shirt,t,1.5,'cloth',1.4);warp(ctx,c.patches.sail,t,3.1,'cloth',2.8);
  glow(ctx,2280,340,530,.023+.008*Math.sin(t*.61),'245,231,174');
 }else if(scene.art==='cypresses.jpg'){
  warp(ctx,c.patches.cypressSky,t,3.8,'cloud',.8);warp(ctx,c.patches.cypressTree,t,11,'tree',.3);warp(ctx,c.patches.field,t,2.0,'cloth',2.4);
  glow(ctx,1000,450,690,.015+.006*Math.sin(t*.46),'243,226,178');
 }else if(scene.art==='wave-met.jpg'){
  warp(ctx,c.patches.wave,t,6.7,'water',1.2);
  ctx.save();ctx.globalAlpha=.33;ctx.fillStyle='#e9e1c9';
  for(let i=0;i<40;i++){const x=850+seed(i+62)*530+Math.sin(t*.28+i)*6,y=390+seed(i+182)*310+(t*3.1)%30;ctx.beginPath();ctx.arc(x,y,.55+seed(i+518)*.65,0,6.28);ctx.fill()}ctx.restore();
 }else if(scene.art==='paper.jpg'){
  // Archival pages breathe through moving light and a grazing shadow, preserving the ink.
  const g=ctx.createLinearGradient(300+t*4,0,1540+t*4,1080);g.addColorStop(0,'rgba(55,40,20,.020)');g.addColorStop(.5,'rgba(255,245,213,.035)');g.addColorStop(1,'rgba(45,30,12,.027)');ctx.fillStyle=g;ctx.fillRect(0,0,1920,1080);
 }
 ctx.restore();
}
export const DynamicArt:React.FC<{scene:Scene;brightness:number}>=({scene,brightness})=>{
 const state=useContext(Context),frame=useCurrentFrame(),ref=useRef<HTMLCanvasElement>(null);
 useLayoutEffect(()=>{if(!state||!ref.current)return;const ctx=ref.current.getContext('2d')!;ctx.clearRect(0,0,W,H);ctx.fillStyle='#071019';ctx.fillRect(0,0,W,H);drawArt(ctx,scene,frame/30,state)},[state,frame,scene]);
 return <canvas ref={ref} width={W} height={H} style={{position:'absolute',inset:0,width:W,height:H,filter:scene.id==='ending'?'none':`brightness(${brightness}) saturate(.91)`}}/>;
};
export const MotionFilm:React.FC=()=>{
 const [handle]=useState(()=>delayRender('Preparing all living paintings')),[state,setState]=useState<State|null>(null);
 useEffect(()=>{
  let alive=true;
  const paths:Record<string,string>={library:'motion-assets/library-clean.png',wheel:'motion-assets/armillary.png',portrait:'art/pearl.jpg',blink:'motion-assets/portrait-blink.png',dawn:'art/dawn.jpg',observatory:'art/observatory.jpg',observatoryClean:'motion-assets/observatory-clean.png',observatoryWheel:'motion-assets/observatory-wheel.png',mountainsClean:'motion-assets/mountains-clean.png',traveler:'motion-assets/traveler.png',travelerStep:'motion-assets/traveler-step.png',city:'art/city.jpg',boating:'art/boating.jpg',cypresses:'art/cypresses.jpg',wave:'art/wave-met.jpg',pitcher:'art/pitcher.jpg',paper:'art/paper.jpg'};
  Promise.all([
   Promise.all(Object.entries(paths).map(async([key,p])=>{const im=new Image();im.src=staticFile(p);await im.decode();return [key,im] as const})),
   document.fonts.ready,
  ]).then(([pairs])=>{if(alive){const a=Object.fromEntries(pairs);setState({a,c:fullPrepare(a)})}}).catch(cancelRender);
  return()=>{alive=false};
 },[]);
 useLayoutEffect(()=>{if(state)continueRender(handle)},[state,handle]);
 return <Context.Provider value={state}>{state&&<Film dynamic/>}</Context.Provider>;
};
