# Echo reference project / 《回声》参考工程

This is an editable Remotion example included with the cinematic-history-remotion skill. It uses public-domain museum scans and original AI-generated scene images. The public package is silent and uses system serif fonts. It contains no personal reference track, copied font files, brand logo vector, or third-party example HTML.

这是 Skill 附带的可编辑 Remotion 案例。公开包保留公有领域名画与原创 AI 场景，默认静音并使用系统衬线字体；不附带个人参考音乐、复制字体、品牌矢量图或第三方参考 HTML。

```bash
npm ci
npm run typecheck
npm run studio
npm run render:motion
```

Select `EchoMotion` in Studio. To make a new film, replace the story, art, and shot parameters. If you add music, use a track you may distribute, add a Remotion `Audio` component, and regenerate any waveform data. `art-sources.json` records museum source links; `assets-generation.json` records prompts for generated scenes. The original film's verification records do not apply to this public template.

在 Studio 中选择 `EchoMotion`。新主题需要改写叙事、画作和镜头参数。如需音乐，请加入有权使用的音轨及 Remotion `Audio` 组件，并重新生成波形。原片的验证记录不适用于此公开模板。

Remotion is a separate dependency governed by its own license: https://www.remotion.dev/docs/license/pricing
