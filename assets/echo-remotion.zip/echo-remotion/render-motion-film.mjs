import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia,renderStill,openBrowser} from '@remotion/renderer';
const root=path.dirname(fileURLToPath(import.meta.url));process.chdir(root);
const browser=process.env.REMOTION_BROWSER_EXECUTABLE;
const out=process.env.REMOTION_OUTPUT_DIR?path.resolve(process.env.REMOTION_OUTPUT_DIR):path.resolve(root,'renders'),qa=path.join(root,'qa-full-motion');fs.mkdirSync(out,{recursive:true});fs.mkdirSync(qa,{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.tsx'),outDir:path.join(root,'build-full-motion')});
const composition=await selectComposition({serveUrl,id:'EchoMotion',browserExecutable:browser,timeoutInMilliseconds:180000});
const mode=process.argv[2]??'film';
if(mode==='stills'){
 const instance=await openBrowser('chrome',{browserExecutable:browser});
 const times=process.argv[3]?process.argv[3].split(',').map(Number):[3,12,21,32,41,51,62,76,87.2,87.6,91,106,115,121,126,135,146,155,163,169,172.5,174.6,176.3,177.9];
 for(const t of times){await renderStill({serveUrl,composition,output:path.join(qa,`frame-${t.toFixed(2)}.jpg`),frame:Math.round(t*30),imageFormat:'jpeg',jpegQuality:95,puppeteerInstance:instance,browserExecutable:browser,timeoutInMilliseconds:180000});console.log('Still',t)}
 await instance.close({silent:true});
}else{
 let last=-1;const draft=mode==='draft';const outputLocation=draft?path.join(root,'renders/full-motion-proof.mp4'):path.join(out,'回声_ChatGPT简史_全片动态升级_1080p.mp4');fs.mkdirSync(path.dirname(outputLocation),{recursive:true});
 await renderMedia({serveUrl,composition,outputLocation,codec:'h264',crf:17,audioBitrate:'320k',pixelFormat:'yuv420p',jpegQuality:93,concurrency:6,browserExecutable:browser,timeoutInMilliseconds:180000,...(draft?{frameRange:[3390,3839]}:{}),onProgress:({progress,renderedFrames,encodedFrames})=>{if(progress-last>.02||progress===1){last=progress;console.log(`${(progress*100).toFixed(1)}% | frames ${renderedFrames} | encoded ${encodedFrames}`)}}});console.log('Saved',outputLocation);
}
