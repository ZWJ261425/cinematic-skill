import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia,renderStill,openBrowser} from '@remotion/renderer';

const root=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const mode=process.argv[2]??'film';
const browser=process.env.REMOTION_BROWSER_EXECUTABLE;
const outDir=path.resolve(process.env.REMOTION_OUTPUT_DIR??path.join(root,'renders'));
fs.mkdirSync(outDir,{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.tsx'),outDir:path.join(root,'build')});
const composition=await selectComposition({serveUrl,id:'Echo',browserExecutable:browser,timeoutInMilliseconds:120000});
console.log('Composition',composition.width,composition.height,composition.durationInFrames,composition.fps);
if(['stills','poster','checks'].includes(mode)){
 const browserInstance=await openBrowser('chrome',{browserExecutable:browser});
 const dir=path.resolve(process.env.REMOTION_QA_DIR??path.join(root,'qa'));fs.mkdirSync(dir,{recursive:true});
 const times=mode==='poster'?[12]:mode==='checks'?[21.6,51.7,76.7,91.8,106.8,146.8,170.8,175.5]:[3,12,21,32,41,51,62,76,91,106,121,135,146,155,163,170,175.5];
 for(const time of times){const output=path.join(dir,`frame-${String(time).padStart(5,'0')}.jpg`);await renderStill({serveUrl,composition,output,frame:Math.round(time*30),imageFormat:'jpeg',jpegQuality:94,puppeteerInstance:browserInstance,browserExecutable:browser,timeoutInMilliseconds:120000});console.log('Still',time);}
 await browserInstance.close({silent:true});
}else{
 const draft=mode==='draft';
 const outputLocation=draft?path.join(outDir,'motion-review.mp4'):path.join(outDir,'回声_ChatGPT简史_至GPT6.1_1080p.mp4');
 let last=0;
 await renderMedia({serveUrl,composition,outputLocation,codec:'h264',crf:draft?22:16,audioBitrate:'320k',pixelFormat:'yuv420p',concurrency:3,browserExecutable:browser,timeoutInMilliseconds:120000, ...(draft?{frameRange:[1980,2339]}:{}),onProgress:({progress,renderedFrames,encodedFrames})=>{if(progress-last>.025||progress===1){last=progress;console.log(`${(progress*100).toFixed(1)}% | rendered ${renderedFrames} | encoded ${encodedFrames}`)}}});
 console.log('Saved',outputLocation);
}
