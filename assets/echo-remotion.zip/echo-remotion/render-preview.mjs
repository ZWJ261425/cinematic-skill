import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia,renderStill,openBrowser} from '@remotion/renderer';
const root=path.dirname(fileURLToPath(import.meta.url));process.chdir(root);
const browser=process.env.REMOTION_BROWSER_EXECUTABLE;
const out=path.resolve(root,'renders');fs.mkdirSync(out,{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.tsx'),outDir:path.join(root,'build-motion')});
const composition=await selectComposition({serveUrl,id:'MotionPreview',browserExecutable:browser,timeoutInMilliseconds:120000});
if(process.argv[2]==='stills'){
 const instance=await openBrowser('chrome',{browserExecutable:browser});
 const qa=path.join(root,'qa-motion');fs.mkdirSync(qa,{recursive:true});
 const times=process.argv[3]?process.argv[3].split(',').map(Number):[1,5,7.5,10.8,11.6,11.68,11.8,12.1,14.5,17.5,20.5,23.5,25,27,29.4];
 for(const t of times){await renderStill({serveUrl,composition,output:path.join(qa,`frame-${t.toFixed(2)}.jpg`),frame:Math.round(t*30),imageFormat:'jpeg',jpegQuality:95,puppeteerInstance:instance,browserExecutable:browser,timeoutInMilliseconds:120000});console.log('Still',t)}
 await instance.close({silent:true});
}else{
 let last=-1;const outputLocation=path.join(out,'回声_动态升级预览_30秒.mp4');
 await renderMedia({serveUrl,composition,outputLocation,codec:'h264',crf:17,audioBitrate:'320k',pixelFormat:'yuv420p',jpegQuality:95,concurrency:3,browserExecutable:browser,timeoutInMilliseconds:120000,onProgress:({progress,renderedFrames,encodedFrames})=>{if(progress-last>.035||progress===1){last=progress;console.log(`${(progress*100).toFixed(1)}% | frames ${renderedFrames} | encoded ${encodedFrames}`)}}});console.log('Saved',outputLocation);
}
